/**
 * 고객과 관리자가 공통으로 사용하는 기능을 모아둔 패키지
 */
package com.java.member;