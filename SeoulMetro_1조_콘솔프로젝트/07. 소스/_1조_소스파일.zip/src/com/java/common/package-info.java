/**
 * 공통 기능을 관리하는 패키지
 */
package com.java.common;