/**
 * 혼잡도 정보 관리하는 패키지
 */
package com.java.busy;