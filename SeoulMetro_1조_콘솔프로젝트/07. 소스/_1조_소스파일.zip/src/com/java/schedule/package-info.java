/**
 * 일정을 관리하는 패키지
 */
package com.java.schedule;