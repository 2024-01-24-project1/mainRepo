/**
 * 행동 로그를 관리하는 패키지
 */
package com.java.common.log;